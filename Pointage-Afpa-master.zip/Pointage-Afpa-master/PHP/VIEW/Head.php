<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title><?php echo "Pointage AFPA"; ?></title>
    <link rel="stylesheet" href="CSS/main.css">
    <link rel="stylesheet" href="CSS/phone.css">
    <link rel="stylesheet" href="CSS/stylesAT.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="CSS/fontawesome/css/all.css">
     <meta name ="viewport" content ="width-device-width,initial-scale=1">
</head>
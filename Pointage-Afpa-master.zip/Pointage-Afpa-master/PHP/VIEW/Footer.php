<div class="dessusFooter"></div>
<footer>
    <div class="espace"></div>
    <p>Afpa @ Copyright 2020</p>
    <img src="Images/logo.svg" alt="logo">
</footer>

<script src="JS/script.js"></script>
<script src="JS/formateur.js"></script>
<script src="JS/selectionOffresAT.js"></script>
</body>
</html>
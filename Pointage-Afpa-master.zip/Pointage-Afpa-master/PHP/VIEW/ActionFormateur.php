<?php
$_SESSION['idOffre'] = $_POST["offre"];
header('Location: index.php?action=InterfaceFormateur');
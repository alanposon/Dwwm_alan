
// **********************mes cartes 
var deck = [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8]
    // **************** ma fonction aleatoire pou melanger 
    .map(tab => [tab, Math.random()]) // on melange notre tableau 
    .sort((deck, place) => deck[1] - place[1]) // on le trie 
    .map(tab => tab[0]) // et on recupere un tableau aleatoirement trier 

// on demande a voir dans la console les places 
console.log(deck);

//  ******************on prend tout les elements img 
var image = document.getElementsByTagName('img');

// pour chaque element on affiche l'image jusqua la taille du tableau 
for (let i = 0; i < image.length; i++) {
    // a chaque tour de boucle on affiche une carte differente 
    image[i].src2 = '../Image/m' + deck[i] + '.jpg';
    // quand on clique sa active la fonction retournement de la carte 
     image[i].addEventListener('click', carteClick); 

 }
function carteClick(e){
//    de la source 1 a la source 2 donc recto verso 
     e.target.src = e.target.src2;
     image[i].removeEventListener('click', carteClick); 
    }


// var image = document.getElementById("test"); 

// image.addEventListener('click', function(e){
//     image.src = '../Image/sangoku.jpg';
// })
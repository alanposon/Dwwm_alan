<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>CRUD WEB</title>
    <link rel="stylesheet" href="CSS/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
	<meta name ="viewport" content ="width-device-width,initial-scale=1">
</head>